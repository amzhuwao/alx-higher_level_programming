Lets learn some javascript
