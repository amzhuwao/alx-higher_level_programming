#!/usr/bin/node
const arr = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
arr.forEach(element => {
  console.log(element);
});
